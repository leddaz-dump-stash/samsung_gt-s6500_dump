<?php
//Disable caching of the current document:
header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header('Pragma: no-cache');

$fileName = 'KiesAirSettings.ini';

function sanitizeString($inStr) {
	$outStr = "";
	for ($i=0; $i<strlen($inStr); $i++) {
		if ($inStr[$i] == "\\") {
			$i++;
		}
		$outStr .= $inStr[$i];
	}
	return $outStr;
}


$json = $_POST['json'];

if ($json) {
	$json = sanitizeString($json);
	if (!$handle = fopen($fileName, 'w')) {
        echo '{"status":"failure","error":"Cannot open file ('.$fileName.')"}';
        exit; 
	}
 	if (fwrite($handle,$json) === FALSE) {
        echo '{"status":"failure","error":"Cannot write to file ('.$fileName.')"}';
       	exit;
 	}
    echo '{"status":"success"}';
	fclose($handle);         
} else {
	$json='{}';
	if (file_exists($fileName)) {
		$json='';
		$handle=fopen($fileName,'rb');
		while(!feof($handle))
    		$json.=fread($handle,2048);
		fclose($handle);
	}
	echo ($json); 
}
?>