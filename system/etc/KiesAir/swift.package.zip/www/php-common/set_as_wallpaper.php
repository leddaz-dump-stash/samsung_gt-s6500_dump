<?php
error_reporting(E_ALL);
require_once dirname(__FILE__) .'/api_call.php';

class SetAsWallPaperWebService extends ApiCall {
	
	public $webservices_homescreen_url;
	public $webservice_imaging_thumbnail_url;

	function __construct() {
		parent::__construct();    	
    	$this->webservices_homescreen_url 		= "http://". '127.0.0.1:'.$_SERVER['SERVER_PORT'] ."/ws/system/homescreen";
    	$this->webservice_imaging_thumbnail_url = "http://". '127.0.0.1:'.$_SERVER['SERVER_PORT'] ."/ws/mm/img";
    }

	public function setAsWallPaper($wallpaper_path)
	{
		// URL-encode according to RFC 1738
		$wallpaper_path = str_replace("%5C", "", rawurlencode ($wallpaper_path));
		
		// get screen dimensions
		$arrResponse = $this->wsCall($this->webservices_homescreen_url.'/dimensions', 'GET');		
		$screenDimensions = $arrResponse['content'];
				
		// get image dimensions		
		$arrResponse = $this->wsCall($this->webservice_imaging_thumbnail_url.'/details/'. $wallpaper_path, 'GET');
		$imgDimensions = $arrResponse['content'];

		// resize photo thumbnail to screen dimensions
		$width = $imgDimensions->width;
		$height= $imgDimensions->height;
		while( ($width > $screenDimensions->width) || ($height > $screenDimensions->height) )
		{
			$width = floor($width * 0.8);
			$height= floor($height* 0.8);
		}
		$bgcolor = 'FF000000';
		$outFileName = 'outImage'.rand().'.png';
		$arrResponse = $this->wsCall($this->webservice_imaging_thumbnail_url.'/thumbnail/'.$width .'x'. $height .'/'. $bgcolor .'/file/'. $wallpaper_path . '/'. $outFileName, 'GET');

		// write image to temporal file
		$outPath = '/sdcard/'. $outFileName;
		$fp = fopen($outPath, 'w');
		fwrite($fp, $arrResponse['content']);		
		fclose($fp);
		
		// set photo as wallpaper
		$params = array('path' => $outPath);
		$arrResponse = $this->wsCall($this->webservices_homescreen_url.'/wallpaper', 'PUT', $params);

		// delete temporal file
		unlink($outPath);
	}
}

$wsSetAsWallPaper = new SetAsWallPaperWebService();
$wsSetAsWallPaper->setAsWallPaper($_GET['path']);
?>