<?php

//error_log("user agent: ".$_SERVER["HTTP_USER_AGENT"]);

function inAgent($string) {
	return !(stripos($_SERVER["HTTP_USER_AGENT"], $string) === false);
}

function isSamsungJet() {
	return (inAgent("SAMSUNG-S8000")); 
}

function isAndroid() {
	return (inAgent("Android")); 
}

function isFirefox() {
	return (inAgent("Firefox"));
}
function isDolphinBrowser() {
	return (inAgent("Dolfin")); 
}
function isMSIE() {
	return (inAgent("MSIE"));
}
?>