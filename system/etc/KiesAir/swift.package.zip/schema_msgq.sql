--The queue table. This must be created before any table is created
--PRAGMA foreign_keys = ON;

CREATE TABLE queue   (
	id TEXT PRIMARY KEY, --Index created
	cid TEXT NOT NULL, 
	msgFlag INTEGER  NOT NULL DEFAULT 0, 
	msgTimeOut INTEGER DEFAULT 0, 
	clients_subscribed INTEGER DEFAULT 0,
	lastest_msgInQ INTEGER DEFAULT NULL,
	ack_qid TEXT DEFAULT NULL, 
	nack_qid TEXT DEFAULT NULL,
    subs_qid TEXT DEFAULT NULL,
    auto_unsubscribe_timeout INTEGER DEFAULT NULL,
    owner_tk TEXT DEFAULT NULL,      --Client cannot DELETE/UPDATE the queue without this token
    publisher_tk TEXT DEFAULT NULL,  --Client cannot publish message to this queue without this token.
    subscriber_tk TEXT DEFAULT NULL, --Client cannot subcriber/unsubcscribe without this token.
    persistent INTEGER DEFAULT 0, -- Queue is persistent, will not be deleted automatically
    unsubscribeMsg TEXT DEFAULT NULL -- Message to send when user unsubscribe or autounsubscribe
);


--The message table
CREATE TABLE message (
	internal_id INTEGER PRIMARY KEY AUTOINCREMENT, --Index created
	id TEXT UNIQUE NOT NULL,
	qid TEXT NOT NULL, --Must map to the Queue. A message cannot exist without the Queue
	cid TEXT NOT NULL,
	_type INTEGER DEFAULT 0, 
	_flags INTEGER DEFAULT 0, 
	exp_ts INTEGER ,
	ts INTEGER , 
	_text TEXT DEFAULT NULL , 
	remaining_clients INTEGER DEFAULT 0
);

--The subscription table
CREATE TABLE subscription (
	cid TEXT  NOT NULL, 
	qid TEXT  NOT NULL, 
	last_msgid_ack INTEGER DEFAULT NULL,
	last_poll INTEGER DEFAULT 0,
	PRIMARY KEY (cid,qid) --Index created
);

--Delete messages when the Queue is deleted.
CREATE TRIGGER deleteMsgOnQDelete DELETE ON queue
BEGIN
DELETE FROM message
WHERE qid = old.id;
END;

--Delete Subscription when the Queue is deleted.
CREATE TRIGGER deleteSubsOnQDelete DELETE ON queue
BEGIN
DELETE FROM subscription
WHERE qid = old.id;
END;

-- updates the lastest_msgInQ column of queue
CREATE TRIGGER updateLastIdInQ AFTER INSERT ON message
BEGIN
UPDATE queue
SET lastest_msgInQ = new.internal_id
WHERE queue.id = new.qid; 
END;

--Update the last_msgid_ack in the subscription table --Change this and get the value from Q
-- in case there are no messages - then use -1 as the value because 0 is a valid msg id!  
CREATE TRIGGER updateLastMsgID AFTER INSERT ON subscription
BEGIN
UPDATE subscription
SET last_msgid_ack = COALESCE((SELECT lastest_msgInQ FROM queue WHERE id=new.qid) , -1)
WHERE rowid = new.rowid;
END;


--Increase the clients_subscribed in the queue table
CREATE TRIGGER updateQForSubscription AFTER INSERT ON subscription
BEGIN
UPDATE queue
SET clients_subscribed = clients_subscribed + 1
WHERE id = new.qid;

--Post message to the Admin Queue if required.
INSERT INTO message (id ,cid, qid, _type,_flags, ts,_text )
SELECT random(), new.cid, queue.subs_qid, 0,NULL,  STRFTIME('%s','now'),'{"subscribedClientId":"' || new.cid ||'" , "totalSubscribedClients":"' || queue.clients_subscribed ||'"}'
FROM queue
WHERE
(id= new.qid) AND (queue.subs_qid IS NOT null);

END;

-- Decrement the clients subscribed in the queue table
CREATE TRIGGER updateQForUnsubscribe AFTER DELETE ON subscription
BEGIN

UPDATE queue
SET clients_subscribed = clients_subscribed - 1
WHERE id = old.qid ;

-- send the unsubscribe message
INSERT INTO message (id ,cid, qid, _type,_flags, ts,_text )
SELECT random() , old.cid, old.qid, 0,NULL,  STRFTIME('%s','now'),unsubscribeMsg
FROM
queue
WHERE
(id= old.qid) AND (unsubscribeMsg IS NOT null);

--Post message to the Admin Queue if required.
INSERT INTO message (id ,cid, qid, _type,_flags, ts,_text )
SELECT random(), old.cid, queue.subs_qid, 0,NULL,  STRFTIME('%s','now'),'{"unsubscribedClientId":"' || old.cid ||'" , "totalSubscribedClients":"' || queue.clients_subscribed ||'"}'
FROM queue
WHERE
(id= old.qid) AND (queue.subs_qid IS NOT null);

END;




-- update the initial number of remaining clients during messge insert
CREATE TRIGGER updateRemainingClients AFTER INSERT ON message
BEGIN
UPDATE message 
SET remaining_clients = (SELECT clients_subscribed FROM queue WHERE (id=new.qid ))-COALESCE((SELECT 1 FROM subscription WHERE (qid=new.qid ) AND (cid=new.cid)),0)
WHERE rowid = new.rowid;
END;

-- set the message flags according to queue default
CREATE TRIGGER updateFlags AFTER INSERT ON message
WHEN (new._type = 0) AND (new._flags IS NULL)
BEGIN
UPDATE message 
SET _flags = (SELECT msgFlag FROM queue WHERE id=new.qid)
WHERE rowid = new.rowid;
END;

--Generate Ack Message if required.
CREATE TRIGGER msgAcknowledged AFTER UPDATE OF remaining_clients ON message
WHEN (new.remaining_clients = 0 AND new._flags & 1 AND NOT (new._flags & 4) AND old.remaining_clients != 0)
BEGIN
INSERT INTO message (id ,cid, qid, _type,_flags, ts,_text )
SELECT new.id || '_a' , new.qid, queue.ack_qid, 1,0,  STRFTIME('%s','now'),'{"acknowledgedMessageId":"' || new.id ||'"}'
FROM
queue
WHERE
(id= new.qid) AND (queue.ack_qid IS NOT null);
END;

-- update the remaining_clients after a nack message is sent
CREATE TRIGGER nackUpdateRemaining AFTER INSERT ON message
WHEN (new._type = 2)
BEGIN
UPDATE message 
SET remaining_clients = 0, _flags = _flags | 4
WHERE id = substr(new.id,0,length(new.id)-2);
END;

-- update remaining_clients property for all messages in range of old.last_msgid_ack and new.last_msgid_ack
CREATE TRIGGER subsUpdateRemainingClients AFTER UPDATE OF last_msgid_ack ON subscription
WHEN (old.last_msgid_ack IS NOT NULL AND new.last_msgid_ack IS NOT NULL AND old.last_msgid_ack<new.last_msgid_ack)
BEGIN
UPDATE message SET remaining_clients = remaining_clients-1
WHERE
(message.qid= new.qid)
AND
(internal_id > old.last_msgid_ack)
AND
(internal_id <= new.last_msgid_ack)
AND
(message.cid != new.cid);
END;
